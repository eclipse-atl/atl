Build library
=============
Launch the lib/build.lib.xml, which copies needed jars from eclipse/plugins to the lib/ directory. 

Build app
=========
Nothing to do here: the application is automatically built by the lib/build.xml ant file, with an Eclipse external tools builder.

Launch app
==========
Use command line to run the "public2private.jar" application, specifying the uml files to privatize as parameters