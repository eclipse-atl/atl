The launch/ directory provides three ways to launch the transformation:
1) public2private (in-place).launch: privatizes the sample uml model and saves changes on the same resources
2) public2private.launch: privatizes the sample uml model and saves changes in another file
3) build.xml: same as 1), but using ATL ant tasks