package org.eclipse.m2m.atl.examples.public2private.ui;

import org.eclipse.ui.plugin.AbstractUIPlugin;

public class PrivatizePlugin extends AbstractUIPlugin {

	public static final String PLUGIN_ID = "org.eclipse.m2m.atl.examples.public2private.ui"; //$NON-NLS-1$

	/** The shared instance. */
	private static PrivatizePlugin plugin;

	public PrivatizePlugin() {
		plugin = this;
	}

	/**
	 * Returns the shared instance.
	 * 
	 * @return the shared instance
	 */
	public static PrivatizePlugin getDefault() {
		return plugin;
	}

}
